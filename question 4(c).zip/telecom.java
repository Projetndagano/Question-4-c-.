/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.questionfour;

/**
 *
 * @author PROJET NDAGANO
 */
public class telecom {
    public static void main(String[] args) {
        int initialBalance = 10000; // UGX
        int loadingCharge = ((initialBalance * 10)/100); // 10% of 10000 ugx=1000
        int callCharge = 200; // shillings per second, so it means that for 5 minutes it will be 5*200
        int callDuration = 5 * 60; // here i want to transform the 5minutes of call in seconds

        int totalCallCharge = callCharge * callDuration;
        // after making the call the balance of the client will be initial balance-loading charge-totalcall charge
        int finalBalance = initialBalance - loadingCharge - totalCallCharge;

        System.out.println("Final balance: " + finalBalance + " UGX");
        
}}


